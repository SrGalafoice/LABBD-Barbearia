package com.fateczl.projeto_barbearia_agendamento.controller;

import com.fateczl.projeto_barbearia_agendamento.model.Agendamento;
import com.fateczl.projeto_barbearia_agendamento.repository.AgendamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/agendamentos")
@CrossOrigin(origins = "*") // Libera o acesso para o Flutter
public class AgendamentoController {

    @Autowired
    private AgendamentoRepository agendamentoRepository;

    // 1. READ (Listar todos)
    @GetMapping
    public List<Agendamento> listarTodos() {
        return agendamentoRepository.findAll();
    }

    // 2. CREATE (Salvar novo)
    @PostMapping
    public Agendamento salvar(@RequestBody Agendamento agendamento) {
        return agendamentoRepository.save(agendamento);
    }

    // 3. UPDATE (Atualizar agendamento existente)
    @PutMapping("/{id}")
    public ResponseEntity<Agendamento> atualizar(@PathVariable Long id, @RequestBody Agendamento agendamentoAtualizado) {
        return agendamentoRepository.findById(id)
                .map(agendamento -> {
                    agendamento.setDataHora(agendamentoAtualizado.getDataHora());
                    agendamento.setStatus(agendamentoAtualizado.getStatus());
                    agendamento.setValorPago(agendamentoAtualizado.getValorPago());

                    // Atualiza também os relacionamentos caso venham no JSON
                    if (agendamentoAtualizado.getCliente() != null) agendamento.setCliente(agendamentoAtualizado.getCliente());
                    if (agendamentoAtualizado.getBarbeiro() != null) agendamento.setBarbeiro(agendamentoAtualizado.getBarbeiro());
                    if (agendamentoAtualizado.getServico() != null) agendamento.setServico(agendamentoAtualizado.getServico());

                    Agendamento salvo = agendamentoRepository.save(agendamento);
                    return ResponseEntity.ok(salvo);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // 4. DELETE (Excluir agendamento)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (agendamentoRepository.existsById(id)) {
            agendamentoRepository.deleteById(id);
            return ResponseEntity.noContent().build(); // Retorna 24 No Content (sucesso)
        }
        return ResponseEntity.notFound().build(); // Retorna 404 se o ID não existir
    }
}